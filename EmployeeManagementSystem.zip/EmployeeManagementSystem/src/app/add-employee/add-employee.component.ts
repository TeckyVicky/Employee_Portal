import { Component, OnInit } from '@angular/core';
import { HttpClientService, Employee } from '../service/http-client.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {


  form = new FormGroup({
    firstName: new FormControl('', Validators.required),
    lastName: new FormControl('', Validators.required),
    department: new FormControl('', Validators.required),
    dob: new FormControl('',Validators.nullValidator),
    gender: new FormControl('',Validators.nullValidator),
   });

  user: Employee = new Employee("","","","","");
  genderValues = [
    {id: "Male", name: "Male"},
    {id: "Female", name: "Female"},
    {id: "Other", name: "Other"}
  ];
  constructor(
    private httpClientService: HttpClientService
  ) { }

  ngOnInit() {
  }

  createEmployee(): void {
    this.httpClientService.createEmployee(this.user)
        .subscribe( data => {
          alert("Employee created successfully.");
          this.clearForm();
        });

  };

  clearForm() {
    this.form.reset({
          'this.user.firstName': '',
          'this.user.lastName': '',
          'this.user.department': '',
          'this.user.dob': '',
          'this.user.gender': '',
         });
    }

}
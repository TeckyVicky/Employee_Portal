package com.emp.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeApp {

	public static void main(String[] args) {
		
		SpringApplication.run(EmployeeApp.class, args);

	}

}


